#!/bin/sh
set -eu

# Uso:
#   ./scripts/restore-db.sh /backups/santos_chamados_YYYYMMDDTHHMMSSZ.dump
#
# NÃO executa restauração destrutiva sem confirmação explícita.

DUMP_FILE="${1:-}"
CONFIRM="${CONFIRM_RESTORE:-}"

if [ -z "${DUMP_FILE}" ]; then
  echo "Informe o arquivo .dump"
  exit 1
fi

if [ "${CONFIRM}" != "YES" ]; then
  echo "Defina CONFIRM_RESTORE=YES para confirmar a restauração destrutiva do banco."
  exit 1
fi

echo "Restaurando ${DUMP_FILE} em ${POSTGRES_DB}..."
pg_restore \
  -h "${POSTGRES_HOST:-santos-chamados-db}" \
  -p "${POSTGRES_PORT:-5432}" \
  -U "${POSTGRES_USER}" \
  -d "${POSTGRES_DB}" \
  --clean \
  --if-exists \
  "${DUMP_FILE}"

echo "Restauração concluída. Reinicie a aplicação e valide a integridade."
