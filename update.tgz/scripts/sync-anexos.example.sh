#!/bin/sh
set -eu

# Exemplo configurável de sincronização de anexos para destino externo.
# Defina ATTACHMENT_SYNC_TARGET (ex.: usuário@host:/caminho ou bucket montado).
# Não invente credenciais neste repositório.

SOURCE="${ATTACHMENT_STORAGE_PATH:-/data/anexos}"
TARGET="${ATTACHMENT_SYNC_TARGET:-}"

if [ -z "${TARGET}" ]; then
  echo "Configure ATTACHMENT_SYNC_TARGET antes de sincronizar anexos."
  exit 1
fi

# Exemplo com rsync (ajuste conforme o destino real):
# rsync -av --delete "${SOURCE}/" "${TARGET}/"

echo "Destino configurado: ${TARGET}"
echo "Implemente o comando de cópia adequado ao seu armazenamento externo."
