package br.com.luancalasans.santoschamados.anexo.repository;

import br.com.luancalasans.santoschamados.anexo.entity.Anexo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnexoRepository extends JpaRepository<Anexo, Long> {

    List<Anexo> findByChamadoIdOrderByCriadoEmAsc(Long chamadoId);

    long countByChamadoId(Long chamadoId);
}
