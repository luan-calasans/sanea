package br.com.luancalasans.santoschamados.chamado.repository;

import br.com.luancalasans.santoschamados.chamado.entity.Chamado;
import br.com.luancalasans.santoschamados.shared.StatusChamado;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.Instant;
import java.util.List;
import java.util.Optional;

public interface ChamadoRepository extends JpaRepository<Chamado, Long> {

    Optional<Chamado> findByProtocolo(String protocolo);

    boolean existsByProtocolo(String protocolo);

    Page<Chamado> findByUsuarioId(Long usuarioId, Pageable pageable);

    @Query("""
            SELECT c FROM Chamado c
            JOIN FETCH c.tipoChamado
            WHERE c.protocolo = :protocolo
            """)
    Optional<Chamado> findByProtocoloWithTipo(@Param("protocolo") String protocolo);

    @Query("""
            SELECT c FROM Chamado c
            JOIN FETCH c.tipoChamado
            LEFT JOIN FETCH c.usuario
            WHERE c.id = :id
            """)
    Optional<Chamado> findDetailedById(@Param("id") Long id);

    @EntityGraph(attributePaths = "tipoChamado")
    @Query(
            value = """
                    SELECT c FROM Chamado c
                    WHERE (:status IS NULL OR c.status = :status)
                      AND (:tipoId IS NULL OR c.tipoChamado.id = :tipoId)
                      AND (:bairro IS NULL OR LOWER(c.bairro) = LOWER(:bairro))
                      AND (:cidade IS NULL OR LOWER(c.cidade) = LOWER(:cidade))
                      AND (:desde IS NULL OR c.abertoEm >= :desde)
                      AND (:ate IS NULL OR c.abertoEm <= :ate)
                      AND (:usuarioId IS NULL OR c.usuario.id = :usuarioId)
                    """,
            countQuery = """
                    SELECT COUNT(c) FROM Chamado c
                    WHERE (:status IS NULL OR c.status = :status)
                      AND (:tipoId IS NULL OR c.tipoChamado.id = :tipoId)
                      AND (:bairro IS NULL OR LOWER(c.bairro) = LOWER(:bairro))
                      AND (:cidade IS NULL OR LOWER(c.cidade) = LOWER(:cidade))
                      AND (:desde IS NULL OR c.abertoEm >= :desde)
                      AND (:ate IS NULL OR c.abertoEm <= :ate)
                      AND (:usuarioId IS NULL OR c.usuario.id = :usuarioId)
                    """
    )
    Page<Chamado> filtrar(
            @Param("status") StatusChamado status,
            @Param("tipoId") Long tipoId,
            @Param("bairro") String bairro,
            @Param("cidade") String cidade,
            @Param("desde") Instant desde,
            @Param("ate") Instant ate,
            @Param("usuarioId") Long usuarioId,
            Pageable pageable
    );

    @Query("SELECT c.status, COUNT(c) FROM Chamado c GROUP BY c.status")
    List<Object[]> countGroupByStatus();

    long countByStatus(StatusChamado status);

    @EntityGraph(attributePaths = "tipoChamado")
    List<Chamado> findTop10ByOrderByAbertoEmDesc();
}
