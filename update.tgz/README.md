# Sistema Web de Gestão de Chamados de Esgoto de Santos

Aplicação Spring Boot 3 para registro e acompanhamento de ocorrências de esgoto no município de Santos/SP.

Perfis: **CIDADAO**, **SABESP**, **PREFEITURA** e **ADMIN**.

URL de produção prevista: `https://app.luancalasans.com.br`  
Origem no Cloudflare Tunnel existente: `http://192.168.0.67:18473`

## Tecnologias

- Java 17, Spring Boot 3, Spring Security 6, Spring Data JPA
- Thymeleaf, HTML5, CSS3, JavaScript, Chart.js, Lucide Icons
- PostgreSQL 16, Flyway
- Bucket4j, Caffeine, Resilience4j
- Docker / Docker Compose
- JUnit 5, Mockito, WireMock, Testcontainers (quando aplicável)

## Requisitos de desenvolvimento

- Docker e Docker Compose
- Java 17+ (opcional localmente; o build oficial usa Maven no Dockerfile)
- Conta SMTP e chaves reCAPTCHA v2 para fluxos reais de cadastro/login

## Estrutura

```text
src/main/java/br/com/luancalasans/santoschamados/
  auth/, usuario/, perfil/, chamado/, mensagem/, anexo/,
  endereco/, dashboard/, auditoria/, catalogo/,
  infrastructure/, shared/
src/main/resources/
  db/migration/, templates/, static/, application*.yml
docker/backup/
scripts/
compose.yaml
Dockerfile
.env.example
```

## Variáveis de ambiente

Copie `.env.example` para `.env` e substitua todos os valores `CHANGE_ME`.

Principais grupos:

- Aplicação / bind (`APP_BIND_IP`, `APP_PORT`, `APP_BASE_URL`)
- PostgreSQL
- reCAPTCHA
- SMTP
- Contas iniciais (`INITIAL_*`)
- Anexos e rate limit
- Backup

O arquivo `.env` real está no `.gitignore`. Em produção, a aplicação **não inicia** com placeholders.

## Execução local com Docker Compose

```bash
cp .env.example .env
# edite .env (para desenvolvimento local pode usar APP_BIND_IP=127.0.0.1 e SPRING_PROFILES_ACTIVE=dev)
docker compose build
docker compose up -d
docker compose ps
docker compose logs -f santos-chamados-app
```

Healthcheck: `http://127.0.0.1:18473/actuator/health` (ou o IP/porta do `.env`).

## Testes

Com Maven local:

```bash
mvn test
```

Com Docker:

```bash
docker run --rm -v "%CD%":/workspace -w /workspace maven:3.9.9-eclipse-temurin-17 mvn -B test
```

Cobertura mínima da fase 1 inclui CEP (orquestração + WireMock), protocolo, transições de status e rate limit.

## Build da imagem

```bash
docker compose build santos-chamados-app
```

A imagem final é JRE enxuta, usuário não-root, heap `-Xms128m -Xmx512m`.

## Deploy no UmbrelOS

Diretório: `/home/umbrel/santos-chamados`

### 1. Verificar porta

```bash
sudo ss -ltnp | grep ':18473 '
sudo docker ps --format "table {{.Names}}\t{{.Ports}}"
```

Não prossiga se a porta estiver ocupada. Não interrompa outros containers.

### 2. Preparar projeto

```bash
mkdir -p /home/umbrel/santos-chamados
# copie os arquivos do projeto para o diretório
cd /home/umbrel/santos-chamados
cp .env.example .env
nano .env
```

### 3. Subir serviços

```bash
./scripts/deploy-umbrel.sh
# ou:
docker compose build
docker compose up -d
docker compose ps
docker compose logs -f santos-chamados-app
```

Validação local no Umbrel:

```text
http://192.168.0.67:18473
http://192.168.0.67:18473/actuator/health
```

### 4. Cloudflare Tunnel (existente)

Não criar outro túnel. No túnel atual, adicione:

```text
Hostname: app.luancalasans.com.br
Service Type: HTTP
Service URL: http://192.168.0.67:18473
```

A aplicação reconhece proxy/`X-Forwarded-*`/`CF-Connecting-IP` apenas de proxies confiáveis configurados em `APP_TRUSTED_PROXIES`.

PostgreSQL **não** é publicado.

## Backups

O serviço `santos-chamados-backup` executa `pg_dump -Fc` diariamente (padrão `0 3 * * *`) com retenção de 14 dias no volume `santos-chamados-backups`.

Restauração (destrutiva, exige confirmação):

```bash
CONFIRM_RESTORE=YES ./scripts/restore-db.sh /backups/santos_chamados_YYYYMMDDTHHMMSSZ.dump
```

Anexos: use `scripts/sync-anexos.example.sh` como base para o destino externo real.

## Atualização de versão

```bash
cd /home/umbrel/santos-chamados
# atualize o código
docker compose build
docker compose up -d
```

Não use `docker compose down -v` em atualizações normais.

## Recuperação de acesso administrativo

1. Acesse o banco via container (rede interna).
2. Confirme se existe ao menos um ADMIN ativo.
3. Se necessário, reative um ADMIN existente (`ativo=true`) ou crie um novo pelo SQL com hash BCrypt e perfil ADMIN.
4. Faça login e troque a senha imediatamente.
5. Registre a operação fora da interface (a UI não altera auditoria).

Nunca desative o último ADMIN pela aplicação; a regra de negócio bloqueia essa operação.

## Troubleshooting

| Sintoma | Verificação |
|---|---|
| App unhealthy | `docker compose logs santos-chamados-app` |
| Falha de migração | logs Flyway / credenciais Postgres |
| Login com reCAPTCHA | chaves `RECAPTCHA_*` e domínio autorizado |
| E-mail de verificação | `SMTP_*` e firewall de saída |
| 502 no Cloudflare | origem `192.168.0.67:18473` e container app healthy |
| Porta ocupada | `ss` / `docker ps` antes do deploy |

## Escopo da fase 1

Inclui login com reCAPTCHA, cadastro/verificação de e-mail, RBAC, chamados, CEP com fallback, anexos, mensagens, consulta pública com rate limit, dashboard, administração, auditoria, Docker, backup e documentação.

Fora da fase 1: notificações automáticas de chamado/mensagem, reset completo de senha, SLA, mapas, WebSocket, tema escuro, exportações e IA.
